$(function(){	

  
	var executed = false;
	$(window).scroll(function(){
		var tt = $('.progress').offset().top - 300;
		console.log(tt);
		if (!executed) {
			if($(this).scrollTop() > tt){
				
			var progressRate = '45';
			
			$({ percent: 0 }).animate({ percent: 45 }, {
				duration: 1500, 
				progress: function () {
					var now = this.percent; //this는 애니메이션 효과를 실행하는 객체
					$('.progress').find('.rate').text(Math.floor(now) + '%');
				}
			});// 각도 애니메이션
			
			$('.progress').addClass('active');
			
			executed = true;			
			}			
		}	
		
		if($(this).scrollTop() > 400){
			$('.back_to_top').fadeIn();
		} else {
			$('.back_to_top').fadeOut();
		}

		$('.back_to_top').click(function(e){
			e.preventDefault();
			$('html,body').stop().animate({scrollTop:0});
		});

		
	});	
		
		
		
		
});