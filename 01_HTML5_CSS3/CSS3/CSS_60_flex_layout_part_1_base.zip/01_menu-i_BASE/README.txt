A Pen created at CodePen.io. You can find this one at http://codepen.io/alikerock/pen/RGvVax.

 For your first project, I’ll demonstrate how to use the CSS flexbox model to simplify the task of evenly spacing out menu items.