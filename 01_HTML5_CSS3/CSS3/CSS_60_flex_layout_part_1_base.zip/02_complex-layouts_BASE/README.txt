A Pen created at CodePen.io. You can find this one at http://codepen.io/alikerock/pen/GjzmOB.

 For years, web designers have relied on floats for website layouts. In this lesson, you will lay out an entire web page using flexbox, which will automatically solve the issue of equal column heights.