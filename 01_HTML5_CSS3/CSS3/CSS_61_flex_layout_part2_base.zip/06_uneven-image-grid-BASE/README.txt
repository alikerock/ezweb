A Pen created at CodePen.io. You can find this one at http://codepen.io/alikerock/pen/LRaPrz.

 This project will be very similar to the previous one, but with a few key differences. These differences will require a slightly different HTML setup, which we’ll talk about in this lesson.