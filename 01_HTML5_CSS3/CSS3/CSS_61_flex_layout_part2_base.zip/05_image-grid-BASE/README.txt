A Pen created at CodePen.io. You can find this one at http://codepen.io/alikerock/pen/RGdbQr.

 In this lesson, you will start by building out the basic styles for an image grid. Once these are set up, the hard work will be dealt with and we’ll be able to finish it off in the next lesson.
