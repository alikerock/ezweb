A Pen created at CodePen.io. You can find this one at http://codepen.io/alikerock/pen/NRoQEY.

 There’s nothing particularly impressive about horizontally centering your content; you’ve been doing it for years. But  what about vertically centering your variable-height content? In this lesson, you’ll learn how flexbox tackles this problem with minimal effort.